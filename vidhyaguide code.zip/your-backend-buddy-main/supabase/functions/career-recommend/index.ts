import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { skills, interests, education, experience, careerGoals } = await req.json();
    if (!skills && !interests) throw new Error("Skills or interests required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are VidyaGuide AI, an expert career counselor. Based on the user's profile, provide personalized career recommendations. Consider current job market trends, emerging roles, salary ranges, and growth potential. Be specific and actionable.`;

    const userPrompt = `Profile:
- Skills: ${Array.isArray(skills) ? skills.join(", ") : skills || "Not specified"}
- Interests: ${Array.isArray(interests) ? interests.join(", ") : interests || "Not specified"}
- Education: ${education || "Not specified"}
- Experience: ${experience || "Not specified"}
- Career Goals: ${careerGoals || "Not specified"}

Provide detailed career recommendations.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "suggest_careers",
            description: "Return structured career recommendations",
            parameters: {
              type: "object",
              properties: {
                recommended_roles: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      match_score: { type: "integer", description: "How well this matches the profile (0-100)" },
                      description: { type: "string" },
                      salary_range: { type: "string" },
                      growth_outlook: { type: "string", enum: ["high", "medium", "low"] },
                      required_skills: { type: "array", items: { type: "string" } },
                      skills_gap: { type: "array", items: { type: "string" } }
                    },
                    required: ["title", "match_score", "description", "salary_range", "growth_outlook", "required_skills"]
                  }
                },
                recommended_skills: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      skill: { type: "string" },
                      importance: { type: "string", enum: ["critical", "important", "nice-to-have"] },
                      learning_resources: { type: "array", items: { type: "string" } }
                    },
                    required: ["skill", "importance"]
                  }
                },
                industry_insights: { type: "string" },
                action_plan: { type: "string", description: "Step-by-step 90-day action plan" }
              },
              required: ["recommended_roles", "recommended_skills", "industry_insights", "action_plan"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "suggest_careers" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const recommendations = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    return new Response(JSON.stringify({ recommendations }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("career-recommend error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
