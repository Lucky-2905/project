import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { skill, level, learningStyle, budget } = await req.json();
    if (!skill) throw new Error("Skill/topic is required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are VidyaGuide AI's course recommendation engine. Recommend real, well-known courses and learning resources from platforms like Coursera, Udemy, YouTube, freeCodeCamp, Khan Academy, edX, Codecademy, LinkedIn Learning, NPTEL, and others. Include actual course names, platforms, instructors where known, and realistic pricing. Prioritize quality and relevance.`;

    const userPrompt = `Find the best courses and learning resources for:
- Skill/Topic: ${skill}
- Current Level: ${level || "Beginner"}
- Preferred Learning Style: ${learningStyle || "Mixed (videos, projects, reading)"}
- Budget: ${budget || "Free to Affordable"}

Recommend real courses with actual details.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "return_courses",
            description: "Return structured course recommendations",
            parameters: {
              type: "object",
              properties: {
                courses: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      platform: { type: "string" },
                      instructor: { type: "string" },
                      url: { type: "string" },
                      price: { type: "string" },
                      is_free: { type: "boolean" },
                      duration: { type: "string" },
                      level: { type: "string", enum: ["beginner", "intermediate", "advanced"] },
                      rating: { type: "string" },
                      description: { type: "string" },
                      skills_covered: { type: "array", items: { type: "string" } },
                      certificate: { type: "boolean" },
                      language: { type: "string" }
                    },
                    required: ["title", "platform", "price", "is_free", "duration", "level", "description"]
                  }
                },
                youtube_channels: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      url: { type: "string" },
                      description: { type: "string" },
                      subscribers: { type: "string" }
                    },
                    required: ["name", "description"]
                  }
                },
                free_resources: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      type: { type: "string" },
                      url: { type: "string" },
                      description: { type: "string" }
                    },
                    required: ["name", "type", "description"]
                  }
                },
                learning_path_suggestion: { type: "string", description: "Recommended order to take these courses" },
                estimated_time_to_proficiency: { type: "string" }
              },
              required: ["courses", "free_resources", "learning_path_suggestion", "estimated_time_to_proficiency"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "return_courses" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) return new Response(JSON.stringify({ error: "Rate limit exceeded." }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (response.status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted." }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const results = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    return new Response(JSON.stringify({ results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("course-search error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
