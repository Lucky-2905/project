import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { currentSkills, targetRole, timeframe, learningStyle } = await req.json();
    if (!targetRole) throw new Error("Target role is required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are VidyaGuide AI, an expert learning path designer. Create personalized, structured learning roadmaps with real resources (free and paid), realistic timelines, and clear milestones. Consider the learner's current skills and preferred learning style.`;

    const userPrompt = `Create a learning roadmap:
- Current Skills: ${Array.isArray(currentSkills) ? currentSkills.join(", ") : currentSkills || "Beginner"}
- Target Role: ${targetRole}
- Timeframe: ${timeframe || "6 months"}
- Learning Style: ${learningStyle || "mixed (videos, projects, reading)"}

Provide a detailed, actionable learning path with real resources.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "create_learning_path",
            description: "Return a structured learning path",
            parameters: {
              type: "object",
              properties: {
                title: { type: "string" },
                description: { type: "string" },
                total_duration: { type: "string" },
                milestones: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      week: { type: "string", description: "e.g., 'Week 1-2'" },
                      title: { type: "string" },
                      objectives: { type: "array", items: { type: "string" } },
                      topics: { type: "array", items: { type: "string" } },
                      project: { type: "string", description: "Hands-on project for this milestone" }
                    },
                    required: ["week", "title", "objectives", "topics"]
                  }
                },
                resources: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      type: { type: "string", enum: ["course", "book", "tutorial", "documentation", "project", "youtube"] },
                      url: { type: "string" },
                      free: { type: "boolean" },
                      description: { type: "string" }
                    },
                    required: ["name", "type", "description", "free"]
                  }
                },
                skills_to_acquire: { type: "array", items: { type: "string" } },
                certifications: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      provider: { type: "string" },
                      difficulty: { type: "string" },
                      url: { type: "string" }
                    },
                    required: ["name", "provider"]
                  }
                },
                tips: { type: "array", items: { type: "string" } }
              },
              required: ["title", "description", "total_duration", "milestones", "resources", "skills_to_acquire"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "create_learning_path" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const learningPath = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    return new Response(JSON.stringify({ learningPath }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("learning-guidance error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
