import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { to, subject, type, data } = await req.json();
    if (!to || !subject) throw new Error("Email recipient and subject are required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Use AI to generate a well-formatted email body
    const systemPrompt = `You are VidyaGuide AI's email composer. Generate professional, well-structured HTML email content. Use clean, modern email-safe HTML (tables for layout, inline styles). Include the VidyaGuide AI branding. The email should be informative, encouraging, and visually appealing.`;

    let userPrompt = "";
    switch (type) {
      case "quiz_result":
        userPrompt = `Generate an HTML email for quiz results:
- Quiz: ${data.quizTitle}
- Score: ${data.score}/${data.totalQuestions}
- Percentage: ${data.percentage}%
- Passed: ${data.passed ? "Yes" : "No"}
- Key areas to improve: ${data.weakAreas?.join(", ") || "None"}
Include congratulations if passed, encouragement if not, and next steps.`;
        break;
      case "career_report":
        userPrompt = `Generate an HTML email for a career recommendation report:
- Top recommended roles: ${data.roles?.map((r: any) => r.title).join(", ")}
- Key skills to develop: ${data.skills?.join(", ")}
- Action plan summary: ${data.actionPlan}
Include a summary of the recommendations and encourage the user to explore the full report.`;
        break;
      case "resume_analysis":
        userPrompt = `Generate an HTML email for a resume analysis report:
- Resume score: ${data.score}/100
- ATS score: ${data.atsScore}/100
- Top strengths: ${data.strengths?.join(", ")}
- Areas to improve: ${data.weaknesses?.join(", ")}
Include the key findings and encourage them to view the full analysis.`;
        break;
      case "learning_path":
        userPrompt = `Generate an HTML email for a learning path notification:
- Path title: ${data.title}
- Target role: ${data.targetRole}
- Duration: ${data.duration}
- Number of milestones: ${data.milestonesCount}
Include a summary and encourage the user to start their learning journey.`;
        break;
      default:
        userPrompt = `Generate a professional HTML notification email with subject "${subject}" and content: ${JSON.stringify(data)}`;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "compose_email",
            description: "Return the composed email HTML",
            parameters: {
              type: "object",
              properties: {
                html_body: { type: "string", description: "Complete HTML email body with inline styles" },
                plain_text: { type: "string", description: "Plain text version of the email" }
              },
              required: ["html_body", "plain_text"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "compose_email" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) return new Response(JSON.stringify({ error: "Rate limit exceeded." }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (response.status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted." }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      throw new Error("AI gateway error");
    }

    const aiData = await response.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    const emailContent = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    // Store the email notification in the database for the user to see
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseKey);

    // Return the generated email content (in a real setup, you'd send via SMTP/Resend)
    // For now, we return the content for client-side preview and download
    return new Response(JSON.stringify({
      success: true,
      email: {
        to,
        subject,
        html: emailContent.html_body,
        plainText: emailContent.plain_text,
      },
      message: "Email content generated. To send emails, connect an email service like Resend."
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("send-email error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
