import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { query, location, experienceLevel, skills } = await req.json();
    if (!query) throw new Error("Search query is required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are VidyaGuide AI's job market analyst. Provide real, current job market data and listings based on the user's query. Include realistic salary ranges, company types, required skills, and application tips. Focus on accuracy and actionable information for the Indian and global job market.`;

    const userPrompt = `Search for jobs matching:
- Role/Query: ${query}
- Location: ${location || "India / Remote"}
- Experience Level: ${experienceLevel || "Entry to Mid"}
- Key Skills: ${Array.isArray(skills) ? skills.join(", ") : skills || "Not specified"}

Provide detailed job listings with salary data, skills required, and market insights.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "return_job_listings",
            description: "Return structured job search results",
            parameters: {
              type: "object",
              properties: {
                jobs: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      company_type: { type: "string", description: "e.g., Startup, MNC, Product-based" },
                      location: { type: "string" },
                      salary_range: { type: "string" },
                      experience_required: { type: "string" },
                      skills_required: { type: "array", items: { type: "string" } },
                      job_description: { type: "string" },
                      application_tips: { type: "string" },
                      platforms: { type: "array", items: { type: "string" }, description: "Where to find this type of job (LinkedIn, Naukri, etc.)" }
                    },
                    required: ["title", "company_type", "location", "salary_range", "skills_required", "job_description"]
                  }
                },
                market_summary: { type: "string", description: "Current job market outlook for this role" },
                demand_level: { type: "string", enum: ["very_high", "high", "moderate", "low"] },
                average_salary: { type: "string" },
                top_hiring_companies: { type: "array", items: { type: "string" } },
                interview_tips: { type: "array", items: { type: "string" } },
                trending_skills: { type: "array", items: { type: "string" } }
              },
              required: ["jobs", "market_summary", "demand_level", "average_salary", "top_hiring_companies"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "return_job_listings" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) return new Response(JSON.stringify({ error: "Rate limit exceeded." }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (response.status === 402) return new Response(JSON.stringify({ error: "AI credits exhausted." }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const results = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    return new Response(JSON.stringify({ results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("job-search error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
