import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { resumeText, targetRole } = await req.json();
    if (!resumeText) throw new Error("Resume text is required");

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const systemPrompt = `You are VidyaGuide AI, an expert resume analyst and career mentor. Analyze the provided resume thoroughly and return a structured JSON response using the suggest_resume_analysis tool. Consider:
- Overall resume quality and formatting
- Skills relevance to the target role (if provided)
- Experience depth and impact descriptions
- Education relevance
- Missing sections or improvements needed
- ATS (Applicant Tracking System) compatibility
- Action verbs and quantifiable achievements
Be specific, actionable, and encouraging.`;

    const userPrompt = targetRole 
      ? `Analyze this resume for the target role of "${targetRole}":\n\n${resumeText}`
      : `Analyze this resume:\n\n${resumeText}`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        tools: [{
          type: "function",
          function: {
            name: "suggest_resume_analysis",
            description: "Return structured resume analysis",
            parameters: {
              type: "object",
              properties: {
                score: { type: "integer", description: "Overall resume score out of 100" },
                summary: { type: "string", description: "Brief overall assessment" },
                strengths: {
                  type: "array",
                  items: { type: "string" },
                  description: "List of resume strengths"
                },
                weaknesses: {
                  type: "array",
                  items: { type: "string" },
                  description: "List of areas for improvement"
                },
                suggestions: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      section: { type: "string" },
                      suggestion: { type: "string" },
                      priority: { type: "string", enum: ["high", "medium", "low"] }
                    },
                    required: ["section", "suggestion", "priority"]
                  },
                  description: "Specific actionable suggestions"
                },
                ats_score: { type: "integer", description: "ATS compatibility score out of 100" },
                missing_keywords: {
                  type: "array",
                  items: { type: "string" },
                  description: "Keywords missing for the target role"
                },
                recommended_skills: {
                  type: "array",
                  items: { type: "string" },
                  description: "Skills to add or highlight"
                }
              },
              required: ["score", "summary", "strengths", "weaknesses", "suggestions", "ats_score"],
              additionalProperties: false
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "suggest_resume_analysis" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again later." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI error:", response.status, t);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    const analysis = toolCall ? JSON.parse(toolCall.function.arguments) : {};

    return new Response(JSON.stringify({ analysis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("resume-analyze error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
