import { useState } from "react";
import { FileText, Upload, Loader2, CheckCircle, AlertTriangle, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { analyzeResume, type ResumeAnalysis } from "@/lib/api";
import { exportResumeAnalysisPDF } from "@/lib/pdf-export";

export default function ResumePage() {
  const [resumeText, setResumeText] = useState("");
  const [targetRole, setTargetRole] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResumeAnalysis | null>(null);
  const { toast } = useToast();

  const handleAnalyze = async () => {
    if (!resumeText.trim()) {
      toast({ title: "Please paste your resume text", variant: "destructive" });
      return;
    }
    setLoading(true);
    setResult(null);
    try {
      const analysis = await analyzeResume(resumeText, targetRole || undefined);
      setResult(analysis);
      toast({ title: "Resume analyzed successfully!" });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleExportPDF = () => {
    if (!result) return;
    exportResumeAnalysisPDF(result);
    toast({ title: "PDF exported!" });
  };

  const scoreColor = (score: number) =>
    score >= 75 ? "text-success" : score >= 50 ? "text-warning" : "text-destructive";

  return (
    <Layout>
      <div className="container py-10 animate-fade-in">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            Resume Analyzer
          </h1>
          <p className="mt-2 text-muted-foreground">
            Paste your resume text below and get AI-powered feedback with ATS scoring.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Input */}
          <div className="space-y-4">
            <Textarea
              placeholder="Paste your resume text here..."
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
              className="min-h-[300px] resize-none"
            />
            <Input
              placeholder="Target role (optional, e.g. Frontend Developer)"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
            />
            <Button
              onClick={handleAnalyze}
              disabled={loading}
              className="w-full gradient-primary border-0 text-primary-foreground"
            >
              {loading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</>
              ) : (
                <><Upload className="mr-2 h-4 w-4" /> Analyze Resume</>
              )}
            </Button>
          </div>

          {/* Results */}
          <div className="space-y-4">
            {loading && (
              <Card>
                <CardContent className="flex items-center justify-center py-20">
                  <div className="text-center">
                    <Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" />
                    <p className="mt-4 text-muted-foreground">Analyzing your resume...</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {result && (
              <>
                {/* Scores */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-display">Scores</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Overall Score</span>
                        <span className={`font-bold ${scoreColor(result.score)}`}>{result.score}/100</span>
                      </div>
                      <Progress value={result.score} className="h-3" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>ATS Compatibility</span>
                        <span className={`font-bold ${scoreColor(result.ats_score)}`}>{result.ats_score}/100</span>
                      </div>
                      <Progress value={result.ats_score} className="h-3" />
                    </div>
                    <p className="text-sm text-muted-foreground">{result.summary}</p>
                  </CardContent>
                </Card>

                {/* Strengths */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-display flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-success" /> Strengths
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {result.strengths.map((s, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="mt-0.5 h-4 w-4 shrink-0 text-success" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Weaknesses */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-display flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-warning" /> Areas to Improve
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {result.weaknesses.map((w, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
                          {w}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Suggestions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="font-display">Suggestions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {result.suggestions.map((s, i) => (
                        <div key={i} className="rounded-lg border border-border p-3">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant={s.priority === "high" ? "destructive" : s.priority === "medium" ? "default" : "secondary"}>
                              {s.priority}
                            </Badge>
                            <span className="font-medium text-sm">{s.section}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{s.suggestion}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Missing Keywords */}
                {result.missing_keywords && result.missing_keywords.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="font-display">Missing Keywords</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {result.missing_keywords.map((k, i) => (
                          <Badge key={i} variant="outline">{k}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Button onClick={handleExportPDF} variant="outline" className="w-full">
                  <ArrowDown className="mr-2 h-4 w-4" /> Export as PDF
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
