import { useState } from "react";
import { BookOpen, Loader2, ExternalLink, Star, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { searchCourses, type CourseSearchResults } from "@/lib/api";

export default function CoursesPage() {
  const [skill, setSkill] = useState("");
  const [level, setLevel] = useState("beginner");
  const [budget, setBudget] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CourseSearchResults | null>(null);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!skill.trim()) { toast({ title: "Enter a skill", variant: "destructive" }); return; }
    setLoading(true); setResult(null);
    try {
      const r = await searchCourses({ skill, level, budget: budget || undefined });
      setResult(r);
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const levelColor = (l: string) =>
    l === "beginner" ? "bg-success/10 text-success" : l === "intermediate" ? "bg-info/10 text-info" : "bg-accent/10 text-accent";

  return (
    <Layout>
      <div className="container py-10 animate-fade-in">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
              <BookOpen className="h-5 w-5 text-success" />
            </div>
            Course Finder
          </h1>
          <p className="mt-2 text-muted-foreground">Find the best courses and resources for any skill.</p>
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid gap-4 sm:grid-cols-3">
              <Input placeholder="Skill (e.g. React, Python, Data Science)" value={skill} onChange={(e) => setSkill(e.target.value)} />
              <Select value={level} onValueChange={setLevel}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Beginner</SelectItem>
                  <SelectItem value="intermediate">Intermediate</SelectItem>
                  <SelectItem value="advanced">Advanced</SelectItem>
                </SelectContent>
              </Select>
              <Input placeholder="Budget (e.g. Free, Under ₹500)" value={budget} onChange={(e) => setBudget(e.target.value)} />
            </div>
            <Button onClick={handleSearch} disabled={loading} className="mt-4 w-full sm:w-auto gradient-primary border-0 text-primary-foreground">
              {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Searching...</> : <><BookOpen className="mr-2 h-4 w-4" /> Find Courses</>}
            </Button>
          </CardContent>
        </Card>

        {loading && (
          <Card><CardContent className="flex items-center justify-center py-20">
            <div className="text-center"><Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" /><p className="mt-4 text-muted-foreground">Finding courses...</p></div>
          </CardContent></Card>
        )}

        {result && (
          <div className="space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <Card><CardContent className="p-4">
                <p className="text-sm font-medium mb-1">Learning Path</p>
                <p className="text-sm text-muted-foreground">{result.learning_path_suggestion}</p>
              </CardContent></Card>
              <Card><CardContent className="p-4">
                <p className="text-sm font-medium mb-1">Time to Proficiency</p>
                <p className="text-sm text-muted-foreground">{result.estimated_time_to_proficiency}</p>
              </CardContent></Card>
            </div>

            <h2 className="font-display text-xl font-semibold">Recommended Courses</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              {result.courses.map((c, i) => (
                <Card key={i}>
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium text-sm">{c.title}</h3>
                      <Badge className={levelColor(c.level)}>{c.level}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">{c.description}</p>
                    <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" />{c.platform}</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{c.duration}</span>
                      {c.rating && <span className="flex items-center gap-1"><Star className="h-3 w-3" />{c.rating}</span>}
                      <span className={c.is_free ? "text-success font-medium" : ""}>{c.price}</span>
                    </div>
                    {c.url && (
                      <a href={c.url} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-primary hover:underline">
                        Visit <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {result.free_resources && result.free_resources.length > 0 && (
              <>
                <h2 className="font-display text-xl font-semibold">Free Resources</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {result.free_resources.map((r, i) => (
                    <Card key={i}><CardContent className="p-4">
                      <Badge variant="secondary" className="mb-2 text-xs">{r.type}</Badge>
                      <h3 className="font-medium text-sm">{r.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{r.description}</p>
                      {r.url && <a href={r.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-xs text-primary hover:underline">Visit <ExternalLink className="h-3 w-3" /></a>}
                    </CardContent></Card>
                  ))}
                </div>
              </>
            )}

            {result.youtube_channels && result.youtube_channels.length > 0 && (
              <>
                <h2 className="font-display text-xl font-semibold">YouTube Channels</h2>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {result.youtube_channels.map((ch, i) => (
                    <Card key={i}><CardContent className="p-4">
                      <h3 className="font-medium text-sm">{ch.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">{ch.description}</p>
                      {ch.subscribers && <p className="text-xs text-muted-foreground mt-1">{ch.subscribers} subscribers</p>}
                    </CardContent></Card>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}
