import { useState } from "react";
import { Search, Loader2, MapPin, DollarSign, TrendingUp, Building } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { searchJobs, type JobSearchResults } from "@/lib/api";

const demandColors: Record<string, string> = {
  very_high: "bg-success text-success-foreground",
  high: "bg-info text-info-foreground",
  moderate: "bg-warning text-warning-foreground",
  low: "bg-muted text-muted-foreground",
};

export default function JobsPage() {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("");
  const [expLevel, setExpLevel] = useState("");
  const [skillsInput, setSkillsInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<JobSearchResults | null>(null);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!query.trim()) { toast({ title: "Enter a job role", variant: "destructive" }); return; }
    setLoading(true); setResult(null);
    try {
      const r = await searchJobs({
        query, location: location || undefined, experienceLevel: expLevel || undefined,
        skills: skillsInput ? skillsInput.split(",").map(s => s.trim()) : undefined,
      });
      setResult(r);
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="container py-10 animate-fade-in">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-info/10">
              <Search className="h-5 w-5 text-info" />
            </div>
            Job Search
          </h1>
          <p className="mt-2 text-muted-foreground">AI-curated job listings with market insights.</p>
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <Input placeholder="Role (e.g. Frontend Developer)" value={query} onChange={(e) => setQuery(e.target.value)} />
              <Input placeholder="Location (e.g. Bangalore)" value={location} onChange={(e) => setLocation(e.target.value)} />
              <Input placeholder="Experience (e.g. 0-2 years)" value={expLevel} onChange={(e) => setExpLevel(e.target.value)} />
              <Input placeholder="Skills (comma-separated)" value={skillsInput} onChange={(e) => setSkillsInput(e.target.value)} />
            </div>
            <Button onClick={handleSearch} disabled={loading} className="mt-4 w-full sm:w-auto gradient-primary border-0 text-primary-foreground">
              {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Searching...</> : <><Search className="mr-2 h-4 w-4" /> Search Jobs</>}
            </Button>
          </CardContent>
        </Card>

        {loading && (
          <Card><CardContent className="flex items-center justify-center py-20">
            <div className="text-center"><Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" /><p className="mt-4 text-muted-foreground">Searching jobs...</p></div>
          </CardContent></Card>
        )}

        {result && (
          <div className="space-y-6">
            {/* Market Summary */}
            <div className="grid gap-4 sm:grid-cols-3">
              <Card><CardContent className="p-4 text-center">
                <TrendingUp className="mx-auto h-6 w-6 text-primary mb-2" />
                <Badge className={demandColors[result.demand_level]}>{result.demand_level.replace("_", " ")}</Badge>
                <p className="mt-1 text-xs text-muted-foreground">Demand Level</p>
              </CardContent></Card>
              <Card><CardContent className="p-4 text-center">
                <DollarSign className="mx-auto h-6 w-6 text-success mb-2" />
                <p className="font-bold text-sm">{result.average_salary}</p>
                <p className="text-xs text-muted-foreground">Average Salary</p>
              </CardContent></Card>
              <Card><CardContent className="p-4 text-center">
                <Building className="mx-auto h-6 w-6 text-secondary mb-2" />
                <p className="text-sm font-medium">{result.top_hiring_companies.slice(0, 3).join(", ")}</p>
                <p className="text-xs text-muted-foreground">Top Companies</p>
              </CardContent></Card>
            </div>

            <Card><CardContent className="p-4"><p className="text-sm text-muted-foreground">{result.market_summary}</p></CardContent></Card>

            {/* Job Listings */}
            {result.jobs.map((job, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-display text-lg font-semibold">{job.title}</h3>
                    <Badge variant="outline">{job.company_type}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-3 text-sm text-muted-foreground mb-3">
                    <span className="flex items-center gap-1"><MapPin className="h-3 w-3" />{job.location}</span>
                    <span className="flex items-center gap-1"><DollarSign className="h-3 w-3" />{job.salary_range}</span>
                    {job.experience_required && <span>{job.experience_required}</span>}
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{job.job_description}</p>
                  <div className="flex flex-wrap gap-1">
                    {job.skills_required.map((s, j) => <Badge key={j} variant="secondary" className="text-xs">{s}</Badge>)}
                  </div>
                  {job.platforms && (
                    <p className="mt-3 text-xs text-muted-foreground">Apply on: {job.platforms.join(", ")}</p>
                  )}
                </CardContent>
              </Card>
            ))}

            {/* Trending Skills */}
            {result.trending_skills && (
              <Card>
                <CardHeader><CardTitle className="font-display">Trending Skills</CardTitle></CardHeader>
                <CardContent><div className="flex flex-wrap gap-2">{result.trending_skills.map((s, i) => <Badge key={i}>{s}</Badge>)}</div></CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}
