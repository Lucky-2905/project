import { useState } from "react";
import { Brain, Loader2, CheckCircle, XCircle, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { generateQuiz, type Quiz } from "@/lib/api";

export default function QuizPage() {
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState("intermediate");
  const [numQuestions, setNumQuestions] = useState("10");
  const [loading, setLoading] = useState(false);
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [showResult, setShowResult] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!topic.trim()) { toast({ title: "Enter a topic", variant: "destructive" }); return; }
    setLoading(true);
    setQuiz(null); setCurrentQ(0); setAnswers([]); setShowResult(false);
    try {
      const q = await generateQuiz({ topic, difficulty, numQuestions: parseInt(numQuestions) });
      setQuiz(q);
      setAnswers(new Array(q.questions.length).fill(null));
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const selectAnswer = (idx: number) => {
    const a = [...answers];
    a[currentQ] = idx;
    setAnswers(a);
  };

  const score = quiz
    ? quiz.questions.reduce((acc, q, i) => acc + (answers[i] === q.correct_answer ? 1 : 0), 0)
    : 0;

  const percentage = quiz ? Math.round((score / quiz.questions.length) * 100) : 0;

  return (
    <Layout>
      <div className="container py-10 animate-fade-in">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10">
              <Brain className="h-5 w-5 text-accent" />
            </div>
            Skill Assessment Quiz
          </h1>
          <p className="mt-2 text-muted-foreground">Generate AI-powered quizzes to test your knowledge.</p>
        </div>

        {!quiz && !loading && (
          <Card className="mx-auto max-w-lg">
            <CardContent className="p-6 space-y-4">
              <Input placeholder="Topic (e.g. React, Machine Learning, Python)" value={topic} onChange={(e) => setTopic(e.target.value)} />
              <div className="grid grid-cols-2 gap-4">
                <Select value={difficulty} onValueChange={setDifficulty}>
                  <SelectTrigger><SelectValue placeholder="Difficulty" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={numQuestions} onValueChange={setNumQuestions}>
                  <SelectTrigger><SelectValue placeholder="Questions" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 Questions</SelectItem>
                    <SelectItem value="10">10 Questions</SelectItem>
                    <SelectItem value="15">15 Questions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleGenerate} className="w-full gradient-primary border-0 text-primary-foreground">
                <Brain className="mr-2 h-4 w-4" /> Generate Quiz
              </Button>
            </CardContent>
          </Card>
        )}

        {loading && (
          <Card className="mx-auto max-w-lg">
            <CardContent className="flex items-center justify-center py-20">
              <div className="text-center"><Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" /><p className="mt-4 text-muted-foreground">Generating quiz...</p></div>
            </CardContent>
          </Card>
        )}

        {quiz && !showResult && (
          <div className="mx-auto max-w-2xl space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold">{quiz.title}</h2>
              <Badge variant="secondary">Q {currentQ + 1}/{quiz.questions.length}</Badge>
            </div>
            <Progress value={((currentQ + 1) / quiz.questions.length) * 100} className="h-2" />

            <Card>
              <CardContent className="p-6">
                <p className="mb-6 font-medium">{quiz.questions[currentQ].question}</p>
                <div className="space-y-3">
                  {quiz.questions[currentQ].options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => selectAnswer(i)}
                      className={`w-full rounded-lg border p-4 text-left text-sm transition-colors ${
                        answers[currentQ] === i
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-border hover:border-primary/50 text-foreground"
                      }`}
                    >
                      <span className="mr-3 font-bold text-muted-foreground">{String.fromCharCode(65 + i)}.</span>
                      {opt}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" disabled={currentQ === 0} onClick={() => setCurrentQ(c => c - 1)}>Previous</Button>
              {currentQ < quiz.questions.length - 1 ? (
                <Button onClick={() => setCurrentQ(c => c + 1)} disabled={answers[currentQ] === null}>Next</Button>
              ) : (
                <Button onClick={() => setShowResult(true)} disabled={answers.some(a => a === null)} className="gradient-primary border-0 text-primary-foreground">Submit Quiz</Button>
              )}
            </div>
          </div>
        )}

        {showResult && quiz && (
          <div className="mx-auto max-w-2xl space-y-6">
            <Card>
              <CardContent className="p-8 text-center">
                <div className={`text-5xl font-display font-bold ${percentage >= quiz.passing_score ? "text-success" : "text-destructive"}`}>
                  {percentage}%
                </div>
                <p className="mt-2 text-muted-foreground">{score}/{quiz.questions.length} correct</p>
                <Badge className="mt-3" variant={percentage >= quiz.passing_score ? "default" : "destructive"}>
                  {percentage >= quiz.passing_score ? "Passed" : "Needs Improvement"}
                </Badge>
              </CardContent>
            </Card>

            {quiz.questions.map((q, i) => (
              <Card key={i} className={answers[i] === q.correct_answer ? "border-success/30" : "border-destructive/30"}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-2 mb-2">
                    {answers[i] === q.correct_answer
                      ? <CheckCircle className="h-5 w-5 text-success shrink-0 mt-0.5" />
                      : <XCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />}
                    <span className="text-sm font-medium">{q.question}</span>
                  </div>
                  <p className="text-xs text-muted-foreground ml-7">
                    Your answer: <strong>{q.options[answers[i]!]}</strong>
                    {answers[i] !== q.correct_answer && <> | Correct: <strong>{q.options[q.correct_answer]}</strong></>}
                  </p>
                  <p className="text-xs text-muted-foreground ml-7 mt-1">{q.explanation}</p>
                </CardContent>
              </Card>
            ))}

            <Button onClick={() => { setQuiz(null); setShowResult(false); }} variant="outline" className="w-full">
              <RotateCw className="mr-2 h-4 w-4" /> Take Another Quiz
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
