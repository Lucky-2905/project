import { Link } from "react-router-dom";
import {
  FileText, Briefcase, Brain, Search, BookOpen, MessageCircle,
  ArrowRight, Sparkles, Target, TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Layout from "@/components/Layout";

const features = [
  {
    icon: FileText,
    title: "Resume Analyzer",
    description: "Get AI-powered resume scoring, ATS optimization, and actionable improvement tips.",
    path: "/resume",
    color: "bg-primary/10 text-primary",
  },
  {
    icon: Briefcase,
    title: "Career Guide",
    description: "Discover best-fit career paths with salary data, skill gaps, and 90-day action plans.",
    path: "/career",
    color: "bg-secondary/10 text-secondary",
  },
  {
    icon: Brain,
    title: "Skill Quiz",
    description: "Test your knowledge with AI-generated quizzes tailored to any topic or role.",
    path: "/quiz",
    color: "bg-accent/10 text-accent",
  },
  {
    icon: Search,
    title: "Job Search",
    description: "Search AI-curated job listings with market insights and interview tips.",
    path: "/jobs",
    color: "bg-info/10 text-info",
  },
  {
    icon: BookOpen,
    title: "Courses",
    description: "Find the best courses, tutorials, and learning resources for any skill.",
    path: "/courses",
    color: "bg-success/10 text-success",
  },
  {
    icon: MessageCircle,
    title: "AI Mentor",
    description: "Chat with your personal AI career mentor for guidance anytime.",
    path: "/chat",
    color: "bg-primary/10 text-primary",
  },
];

const stats = [
  { icon: Sparkles, label: "AI-Powered", value: "8 Tools" },
  { icon: Target, label: "Accuracy", value: "ATS Ready" },
  { icon: TrendingUp, label: "Growth", value: "90-Day Plans" },
];

export default function Index() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero opacity-10" />
        <div className="container relative py-20 md:py-32">
          <div className="mx-auto max-w-3xl text-center animate-fade-in">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm font-medium text-muted-foreground">
              <Sparkles className="h-4 w-4 text-primary" />
              AI-Powered Career Platform
            </div>
            <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Your Career Journey,{" "}
              <span className="gradient-text">Supercharged by AI</span>
            </h1>
            <p className="mt-6 text-lg text-muted-foreground md:text-xl">
              VidyaGuide AI helps students and professionals with resume analysis,
              career planning, skill assessments, job search, and personalized mentoring.
            </p>
            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
              <Button asChild size="lg" className="gradient-primary border-0 text-primary-foreground px-8">
                <Link to="/resume">
                  Analyze My Resume <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/chat">Talk to AI Mentor</Link>
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-3 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="mx-auto mb-2 h-6 w-6 text-primary" />
                <div className="font-display text-2xl font-bold">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container pb-20">
        <div className="mb-12 text-center">
          <h2 className="font-display text-3xl font-bold">Everything You Need</h2>
          <p className="mt-3 text-muted-foreground">
            Six powerful AI tools to accelerate your career growth.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Link key={f.path} to={f.path}>
              <Card className="group h-full transition-all hover:shadow-lg hover:-translate-y-1 border-border">
                <CardContent className="p-6">
                  <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl ${f.color}`}>
                    <f.icon className="h-6 w-6" />
                  </div>
                  <h3 className="font-display text-lg font-semibold">{f.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{f.description}</p>
                  <div className="mt-4 flex items-center text-sm font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
                    Get Started <ArrowRight className="ml-1 h-4 w-4" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </Layout>
  );
}
