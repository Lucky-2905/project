import { useState } from "react";
import { Briefcase, Loader2, TrendingUp, Star, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/Layout";
import { getCareerRecommendations, type CareerRecommendation } from "@/lib/api";
import { exportCareerRecommendationPDF } from "@/lib/pdf-export";

export default function CareerPage() {
  const [skills, setSkills] = useState("");
  const [interests, setInterests] = useState("");
  const [education, setEducation] = useState("");
  const [experience, setExperience] = useState("");
  const [goals, setGoals] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CareerRecommendation | null>(null);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!skills && !interests) {
      toast({ title: "Please enter skills or interests", variant: "destructive" });
      return;
    }
    setLoading(true);
    setResult(null);
    try {
      const data = await getCareerRecommendations({
        skills: skills.split(",").map(s => s.trim()).filter(Boolean),
        interests: interests.split(",").map(s => s.trim()).filter(Boolean),
        education, experience, careerGoals: goals,
      });
      setResult(data);
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const outlookColor = (o: string) =>
    o === "high" ? "text-success" : o === "medium" ? "text-warning" : "text-muted-foreground";

  return (
    <Layout>
      <div className="container py-10 animate-fade-in">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary/10">
              <Briefcase className="h-5 w-5 text-secondary" />
            </div>
            Career Guide
          </h1>
          <p className="mt-2 text-muted-foreground">
            Get personalized career recommendations with salary data and action plans.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          <div className="space-y-4">
            <Input placeholder="Skills (comma-separated, e.g. Python, React, SQL)" value={skills} onChange={(e) => setSkills(e.target.value)} />
            <Input placeholder="Interests (e.g. AI, Web Development, Data Science)" value={interests} onChange={(e) => setInterests(e.target.value)} />
            <Input placeholder="Education (e.g. B.Tech CS)" value={education} onChange={(e) => setEducation(e.target.value)} />
            <Input placeholder="Experience (e.g. 2 years in web dev)" value={experience} onChange={(e) => setExperience(e.target.value)} />
            <Input placeholder="Career goals (optional)" value={goals} onChange={(e) => setGoals(e.target.value)} />
            <Button onClick={handleSubmit} disabled={loading} className="w-full gradient-primary border-0 text-primary-foreground">
              {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</> : <><TrendingUp className="mr-2 h-4 w-4" /> Get Recommendations</>}
            </Button>
          </div>

          <div className="space-y-4">
            {loading && (
              <Card><CardContent className="flex items-center justify-center py-20">
                <div className="text-center"><Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" /><p className="mt-4 text-muted-foreground">Analyzing your profile...</p></div>
              </CardContent></Card>
            )}

            {result && (
              <>
                {result.recommended_roles.map((role, i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="font-display text-lg font-semibold">{role.title}</h3>
                        <Badge variant="secondary">{role.match_score}% Match</Badge>
                      </div>
                      <Progress value={role.match_score} className="h-2 mb-3" />
                      <p className="text-sm text-muted-foreground mb-3">{role.description}</p>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div>
                          <span className="text-muted-foreground">Salary:</span>
                          <span className="ml-1 font-medium">{role.salary_range}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Growth:</span>
                          <span className={`ml-1 font-medium ${outlookColor(role.growth_outlook)}`}>
                            {role.growth_outlook}
                          </span>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-1">
                        {role.required_skills.map((s, j) => (
                          <Badge key={j} variant="outline" className="text-xs">{s}</Badge>
                        ))}
                      </div>
                      {role.skills_gap && role.skills_gap.length > 0 && (
                        <div className="mt-3">
                          <span className="text-xs text-muted-foreground">Skills gap: </span>
                          {role.skills_gap.map((s, j) => (
                            <Badge key={j} variant="destructive" className="text-xs mr-1">{s}</Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}

                {/* Skills to Learn */}
                <Card>
                  <CardHeader><CardTitle className="font-display flex items-center gap-2"><Star className="h-5 w-5 text-accent" /> Skills to Learn</CardTitle></CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {result.recommended_skills.map((s, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <Badge variant={s.importance === "critical" ? "destructive" : s.importance === "important" ? "default" : "secondary"} className="text-xs">{s.importance}</Badge>
                          <span className="text-sm">{s.skill}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Action Plan */}
                <Card>
                  <CardHeader><CardTitle className="font-display">90-Day Action Plan</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">{result.action_plan}</p>
                  </CardContent>
                </Card>

                {/* Insights */}
                <Card>
                  <CardHeader><CardTitle className="font-display">Industry Insights</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">{result.industry_insights}</p>
                  </CardContent>
                </Card>

                <Button onClick={() => { exportCareerRecommendationPDF(result); toast({ title: "PDF exported!" }); }} variant="outline" className="w-full">
                  <ArrowDown className="mr-2 h-4 w-4" /> Export as PDF
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
