import { supabase } from "@/integrations/supabase/client";

// ============ Resume Analysis ============
export interface ResumeAnalysis {
  score: number;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  suggestions: { section: string; suggestion: string; priority: "high" | "medium" | "low" }[];
  ats_score: number;
  missing_keywords?: string[];
  recommended_skills?: string[];
}

export async function analyzeResume(resumeText: string, targetRole?: string): Promise<ResumeAnalysis> {
  const { data, error } = await supabase.functions.invoke("resume-analyze", {
    body: { resumeText, targetRole },
  });
  if (error) throw new Error(error.message || "Failed to analyze resume");
  if (data?.error) throw new Error(data.error);
  return data.analysis;
}

// ============ Career Recommendations ============
export interface CareerRole {
  title: string;
  match_score: number;
  description: string;
  salary_range: string;
  growth_outlook: "high" | "medium" | "low";
  required_skills: string[];
  skills_gap?: string[];
}

export interface CareerRecommendation {
  recommended_roles: CareerRole[];
  recommended_skills: { skill: string; importance: string; learning_resources?: string[] }[];
  industry_insights: string;
  action_plan: string;
}

export async function getCareerRecommendations(profile: {
  skills?: string[];
  interests?: string[];
  education?: string;
  experience?: string;
  careerGoals?: string;
}): Promise<CareerRecommendation> {
  const { data, error } = await supabase.functions.invoke("career-recommend", {
    body: profile,
  });
  if (error) throw new Error(error.message || "Failed to get recommendations");
  if (data?.error) throw new Error(data.error);
  return data.recommendations;
}

// ============ Quiz Generation ============
export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correct_answer: number;
  explanation: string;
  difficulty?: "easy" | "medium" | "hard";
}

export interface Quiz {
  title: string;
  description: string;
  questions: QuizQuestion[];
  passing_score: number;
  time_limit_minutes?: number;
}

export async function generateQuiz(params: {
  topic: string;
  difficulty?: string;
  numQuestions?: number;
  quizType?: string;
}): Promise<Quiz> {
  const { data, error } = await supabase.functions.invoke("generate-quiz", {
    body: params,
  });
  if (error) throw new Error(error.message || "Failed to generate quiz");
  if (data?.error) throw new Error(data.error);
  return data.quiz;
}

// ============ Learning Guidance ============
export interface LearningMilestone {
  week: string;
  title: string;
  objectives: string[];
  topics: string[];
  project?: string;
}

export interface LearningResource {
  name: string;
  type: "course" | "book" | "tutorial" | "documentation" | "project" | "youtube";
  url?: string;
  free: boolean;
  description: string;
}

export interface LearningPath {
  title: string;
  description: string;
  total_duration: string;
  milestones: LearningMilestone[];
  resources: LearningResource[];
  skills_to_acquire: string[];
  certifications?: { name: string; provider: string; difficulty?: string; url?: string }[];
  tips?: string[];
}

export async function getLearningGuidance(params: {
  currentSkills?: string[];
  targetRole: string;
  timeframe?: string;
  learningStyle?: string;
}): Promise<LearningPath> {
  const { data, error } = await supabase.functions.invoke("learning-guidance", {
    body: params,
  });
  if (error) throw new Error(error.message || "Failed to get learning guidance");
  if (data?.error) throw new Error(data.error);
  return data.learningPath;
}

// ============ AI Chat (Streaming) ============
type ChatMessage = { role: "user" | "assistant"; content: string };

export async function streamChat({
  messages,
  onDelta,
  onDone,
  onError,
}: {
  messages: ChatMessage[];
  onDelta: (text: string) => void;
  onDone: () => void;
  onError?: (error: Error) => void;
}) {
  const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;

  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
      },
      body: JSON.stringify({ messages }),
    });

    if (!resp.ok) {
      const errorData = await resp.json().catch(() => ({}));
      throw new Error(errorData.error || `Chat failed with status ${resp.status}`);
    }

    if (!resp.body) throw new Error("No response body");

    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let done = false;

    while (!done) {
      const { done: readerDone, value } = await reader.read();
      if (readerDone) break;
      buffer += decoder.decode(value, { stream: true });

      let newlineIndex: number;
      while ((newlineIndex = buffer.indexOf("\n")) !== -1) {
        let line = buffer.slice(0, newlineIndex);
        buffer = buffer.slice(newlineIndex + 1);

        if (line.endsWith("\r")) line = line.slice(0, -1);
        if (line.startsWith(":") || line.trim() === "") continue;
        if (!line.startsWith("data: ")) continue;

        const jsonStr = line.slice(6).trim();
        if (jsonStr === "[DONE]") {
          done = true;
          break;
        }

        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) onDelta(content);
        } catch {
          buffer = line + "\n" + buffer;
          break;
        }
      }
    }

    // Final flush
    if (buffer.trim()) {
      for (let raw of buffer.split("\n")) {
        if (!raw) continue;
        if (raw.endsWith("\r")) raw = raw.slice(0, -1);
        if (raw.startsWith(":") || raw.trim() === "") continue;
        if (!raw.startsWith("data: ")) continue;
        const jsonStr = raw.slice(6).trim();
        if (jsonStr === "[DONE]") continue;
        try {
          const parsed = JSON.parse(jsonStr);
          const content = parsed.choices?.[0]?.delta?.content as string | undefined;
          if (content) onDelta(content);
        } catch { /* ignore */ }
      }
    }

    onDone();
  } catch (e) {
    const error = e instanceof Error ? e : new Error("Unknown error");
    onError?.(error);
  }
}

// ============ Job Search ============
export interface JobListing {
  title: string;
  company_type: string;
  location: string;
  salary_range: string;
  experience_required?: string;
  skills_required: string[];
  job_description: string;
  application_tips?: string;
  platforms?: string[];
}

export interface JobSearchResults {
  jobs: JobListing[];
  market_summary: string;
  demand_level: "very_high" | "high" | "moderate" | "low";
  average_salary: string;
  top_hiring_companies: string[];
  interview_tips?: string[];
  trending_skills?: string[];
}

export async function searchJobs(params: {
  query: string;
  location?: string;
  experienceLevel?: string;
  skills?: string[];
}): Promise<JobSearchResults> {
  const { data, error } = await supabase.functions.invoke("job-search", {
    body: params,
  });
  if (error) throw new Error(error.message || "Failed to search jobs");
  if (data?.error) throw new Error(data.error);
  return data.results;
}

// ============ Course Search ============
export interface Course {
  title: string;
  platform: string;
  instructor?: string;
  url?: string;
  price: string;
  is_free: boolean;
  duration: string;
  level: "beginner" | "intermediate" | "advanced";
  rating?: string;
  description: string;
  skills_covered?: string[];
  certificate?: boolean;
  language?: string;
}

export interface CourseSearchResults {
  courses: Course[];
  youtube_channels?: { name: string; url?: string; description: string; subscribers?: string }[];
  free_resources?: { name: string; type: string; url?: string; description: string }[];
  learning_path_suggestion: string;
  estimated_time_to_proficiency: string;
}

export async function searchCourses(params: {
  skill: string;
  level?: string;
  learningStyle?: string;
  budget?: string;
}): Promise<CourseSearchResults> {
  const { data, error } = await supabase.functions.invoke("course-search", {
    body: params,
  });
  if (error) throw new Error(error.message || "Failed to search courses");
  if (data?.error) throw new Error(data.error);
  return data.results;
}

// ============ Email Notifications ============
export async function sendEmailNotification(params: {
  to: string;
  subject: string;
  type: "quiz_result" | "career_report" | "resume_analysis" | "learning_path";
  data: Record<string, any>;
}): Promise<{ success: boolean; email?: any; message?: string }> {
  const { data, error } = await supabase.functions.invoke("send-email", {
    body: params,
  });
  if (error) throw new Error(error.message || "Failed to send email");
  if (data?.error) throw new Error(data.error);
  return data;
}
